import { useState, useEffect } from 'react'
import { Link, useSearchParams, useNavigate } from 'react-router-dom'
import { LogIn, Mail, Lock, Eye, EyeOff, ShieldCheck } from 'lucide-react'
import { useAuth } from '../shared/hooks/useAuth'
import { useI18n } from '../i18n'
import { login as entraLogin } from '../services/authService'
import './SignIn.css'

export default function SignIn() {
  const { isAuthenticated } = useAuth()
  const { t } = useI18n()
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const returnUrl = searchParams.get('returnUrl') || '/'

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [token, setToken] = useState('')

  useEffect(() => {
    if (isAuthenticated) {
      navigate(returnUrl, { replace: true })
    }
  }, [isAuthenticated, returnUrl, navigate])

  useEffect(() => {
    fetch('/_layout/tokenhtml')
      .then(r => r.text())
      .then(html => {
        const match = html.match(/value="([^"]+)"/)
        if (match) setToken(match[1])
      })
      .catch(() => {})
  }, [])

  const handleLocalLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) {
      setError(t('signIn.errorEmail'))
      return
    }
    if (!password) {
      setError(t('signIn.errorPassword'))
      return
    }

    setError('')
    setIsSubmitting(true)

    const form = document.createElement('form')
    form.method = 'POST'
    form.action = '/SignIn'
    form.style.display = 'none'

    const fields: Record<string, string> = {
      __RequestVerificationToken: token,
      Username: email.trim(),
      Password: password,
      RememberMe: 'true',
      returnUrl,
    }

    for (const [key, value] of Object.entries(fields)) {
      const input = document.createElement('input')
      input.type = 'hidden'
      input.name = key
      input.value = value
      form.appendChild(input)
    }

    document.body.appendChild(form)
    form.submit()
  }

  const handleEntraLogin = async () => {
    setError('')
    setIsSubmitting(true)
    try {
      await entraLogin(returnUrl)
    } catch {
      setError(t('signIn.errorGeneral'))
      setIsSubmitting(false)
    }
  }

  if (isAuthenticated) return null

  return (
    <div className="page signin-page">
      <div className="container" style={{ maxWidth: 480 }}>
        <div className="signin-card card animate-in animate-in-1">
          <div className="signin-header">
            <div className="signin-icon">
              <LogIn size={28} />
            </div>
            <h1 className="signin-title">{t('signIn.title')}</h1>
            <p className="signin-subtitle">
              {t('signIn.subtitle')}
            </p>
          </div>

          {/* Microsoft Entra ID */}
          <button
            type="button"
            className="signin-entra-btn"
            onClick={handleEntraLogin}
          >
            <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="1" y="1" width="9" height="9" fill="#F25022"/>
              <rect x="11" y="1" width="9" height="9" fill="#7FBA00"/>
              <rect x="1" y="11" width="9" height="9" fill="#00A4EF"/>
              <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
            </svg>
            {t('signIn.microsoft')}
          </button>

          <div className="signin-divider">
            <span>{t('signIn.orEmail')}</span>
          </div>

          {/* Local login form */}
          <form onSubmit={handleLocalLogin} className="signin-form" noValidate>
            {error && (
              <div className="signin-error animate-in">
                {error}
              </div>
            )}

            <div className="form-group">
              <label className="form-label" htmlFor="signin-email">{t('signIn.emailLabel')}</label>
              <div className="signin-input-wrapper">
                <Mail size={18} className="signin-input-icon" />
                <input
                  id="signin-email"
                  type="email"
                  className="form-input signin-input-with-icon"
                  placeholder="you@example.com"
                  value={email}
                  onChange={e => { setEmail(e.target.value); setError('') }}
                  autoComplete="email"
                  autoFocus
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="signin-password">{t('signIn.passwordLabel')}</label>
              <div className="signin-input-wrapper">
                <Lock size={18} className="signin-input-icon" />
                <input
                  id="signin-password"
                  type={showPassword ? 'text' : 'password'}
                  className="form-input signin-input-with-icon"
                  placeholder={t('signIn.passwordPlaceholder')}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError('') }}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="signin-toggle-password"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary signin-submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? t('signIn.signingIn') : t('common.signIn')}
            </button>
          </form>

          <div className="signin-footer">
            <a href="/Account/Login/ForgotPassword" className="signin-link">
              {t('signIn.forgotPassword')}
            </a>
            <span className="signin-footer-sep">&middot;</span>
            <a href="/Account/Login/Register" className="signin-link">
              {t('signIn.createAccount')}
            </a>
          </div>
        </div>

        <div className="signin-trust animate-in animate-in-2">
          <ShieldCheck size={16} />
          <span>{t('signIn.trustBadge')}</span>
        </div>

        <div className="signin-back animate-in animate-in-3">
          <Link to="/">{t('common.backToHome')}</Link>
        </div>
      </div>
    </div>
  )
}
