import { Routes, Route, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import Layout from './components/Layout'
import AuthGate from './components/AuthGate'
import { useI18n } from './i18n'
import Home from './pages/Home'
import Services from './pages/Services'
import ServiceDetail from './pages/ServiceDetail'
import CreateRequest from './pages/CreateRequest'
import Track from './pages/Track'
import RequestMap from './pages/RequestMap'
import Knowledge from './pages/Knowledge'
import ArticleDetail from './pages/ArticleDetail'
import Contact from './pages/Contact'
import Admin from './pages/Admin'
import SignIn from './pages/SignIn'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => { window.scrollTo(0, 0) }, [pathname])
  return null
}

export default function App() {
  const { t } = useI18n()

  return (
    <Layout>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<Services />} />
        <Route path="/services/:slug" element={<ServiceDetail />} />
        <Route path="/request/new/:slug" element={
          <AuthGate message={t('auth.signInToSubmit')}>
            <CreateRequest />
          </AuthGate>
        } />
        <Route path="/track" element={
          <AuthGate message={t('auth.signInToTrack')}>
            <Track />
          </AuthGate>
        } />
        <Route path="/requests/map" element={<RequestMap />} />
        <Route path="/knowledge" element={<Knowledge />} />
        <Route path="/knowledge/:slug" element={<ArticleDetail />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </Layout>
  )
}
