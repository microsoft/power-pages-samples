#!/usr/bin/env python3
"""
Playwright test script to verify badge visibility across different viewports.
Tests desktop (1920x1080) and mobile (390x844) viewports.
"""

import sys
import asyncio
import subprocess
import time
import os
from pathlib import Path

# Add the webapp-testing helper to the path
helper_path = Path("/Users/priyanshuag/.copilot/installed-plugins/anthropic-agent-skills/document-skills/skills/webapp-testing/scripts")
if helper_path.exists():
    sys.path.insert(0, str(helper_path))

try:
    from with_server import run_with_server
except ImportError:
    print("Error: Could not import with_server from webapp-testing helper")
    print(f"Helper path: {helper_path}")
    sys.exit(1)

from playwright.async_api import async_playwright, expect


async def test_badge_desktop(page):
    """Test badge visibility and attributes on desktop viewport (1920x1080)"""
    print("\n=== DESKTOP VIEWPORT TEST (1920x1080) ===")
    
    # Navigate to the page
    await page.goto("/", wait_until="networkidle")
    await page.wait_for_load_state("domcontentloaded")
    
    # Check for exactly one .powered-badge element
    badges = await page.locator(".powered-badge").count()
    print(f"Badge count: {badges}")
    assert badges == 1, f"Expected exactly 1 badge, found {badges}"
    
    # Get the badge element
    badge = page.locator(".powered-badge").first
    
    # Check visibility
    is_visible = await badge.is_visible()
    print(f"Badge is visible: {is_visible}")
    assert is_visible, "Badge should be visible on desktop"
    
    # Check text content
    text = await badge.text_content()
    print(f"Badge text: '{text}'")
    assert text and "Built with Microsoft Power Pages" in text, f"Unexpected badge text: '{text}'"
    
    # Check child img attributes
    img = badge.locator("img")
    img_count = await img.count()
    print(f"Child img count: {img_count}")
    assert img_count == 1, f"Expected 1 child img, found {img_count}"
    
    # Check img attributes
    alt = await img.get_attribute("alt")
    aria_hidden = await img.get_attribute("aria-hidden")
    width = await img.get_attribute("width")
    height = await img.get_attribute("height")
    
    print(f"Img alt attribute: '{alt}'")
    print(f"Img aria-hidden attribute: '{aria_hidden}'")
    print(f"Img width attribute: '{width}'")
    print(f"Img height attribute: '{height}'")
    
    assert alt == "", f"Expected alt='', got alt='{alt}'"
    assert aria_hidden == "true", f"Expected aria-hidden='true', got aria-hidden='{aria_hidden}'"
    assert width == "14", f"Expected width='14', got width='{width}'"
    assert height == "14", f"Expected height='14', got height='{height}'"
    
    # Take screenshot
    screenshot_path = "/tmp/desktop_badge.png"
    await page.screenshot(path=screenshot_path)
    print(f"Screenshot saved to: {screenshot_path}")
    
    print("✓ Desktop viewport test PASSED")
    return True


async def test_badge_mobile(page):
    """Test badge visibility on mobile viewport (390x844)"""
    print("\n=== MOBILE VIEWPORT TEST (390x844) ===")
    
    # Set mobile viewport
    await page.set_viewport_size({"width": 390, "height": 844})
    
    # Navigate to the page
    await page.goto("/", wait_until="networkidle")
    await page.wait_for_load_state("domcontentloaded")
    
    # Check for badge visibility
    badges = await page.locator(".powered-badge").count()
    print(f"Badge count: {badges}")
    
    if badges > 0:
        badge = page.locator(".powered-badge").first
        is_visible = await badge.is_visible()
        print(f"Badge is visible: {is_visible}")
        assert not is_visible, "Badge should be hidden/not visible on mobile (390px width)"
    else:
        print("No badge elements found on mobile view (expected)")
    
    # Take screenshot
    screenshot_path = "/tmp/mobile_badge.png"
    await page.screenshot(path=screenshot_path)
    print(f"Screenshot saved to: {screenshot_path}")
    
    print("✓ Mobile viewport test PASSED")
    return True


async def run_tests():
    """Main test runner using the with_server helper"""
    
    print("Starting Playwright tests with Vite dev server...")
    print("Testing badge visibility across viewports")
    
    async def test_fn(browser_context):
        """Test function that runs with the dev server"""
        page = await browser_context.new_page()
        
        # First set desktop viewport
        await page.set_viewport_size({"width": 1920, "height": 1080})
        
        try:
            # Run desktop test
            await test_badge_desktop(page)
            
            # Run mobile test
            await test_badge_mobile(page)
            
            print("\n" + "="*50)
            print("✓ ALL TESTS PASSED")
            print("="*50)
            
        except AssertionError as e:
            print(f"\n✗ TEST FAILED: {e}")
            raise
        finally:
            await page.close()
    
    # Use the with_server helper to run tests with dev server on port 5173
    try:
        await run_with_server(
            test_fn,
            dev_server_url="http://localhost:5173",
            dev_server_cmd=["npm", "run", "dev"],
            wait_for_ready=3.0,
            cwd="/Users/priyanshuag/Downloads/Zava 311 wo Node"
        )
    except Exception as e:
        print(f"Error running tests: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(run_tests())
