import { type ReactNode } from 'react'
import Header from './Header'
import Footer from './Footer'
import PowerPagesBadge from './PowerPagesBadge'

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Header />
      <main style={{ flex: 1 }}>{children}</main>
      <Footer />
      <PowerPagesBadge />
    </div>
  )
}
