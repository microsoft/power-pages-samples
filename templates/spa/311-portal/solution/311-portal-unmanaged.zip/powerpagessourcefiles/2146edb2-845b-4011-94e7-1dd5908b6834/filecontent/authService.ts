import type { PowerPagesPortalUser } from '../types/user'

const isDevelopment =
  typeof window !== 'undefined' &&
  (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')

// Mock user for local development — auth only works on deployed Power Pages sites
const MOCK_USER: PowerPagesPortalUser = {
  userName: 'dev@zavacity.gov',
  firstName: 'Dev',
  lastName: 'User',
  email: 'dev@zavacity.gov',
  contactId: '00000000-0000-0000-0000-000000000001',
  userRoles: ['Authenticated Users'],
}

/**
 * Returns the currently logged-in portal user object, or undefined if not authenticated.
 */
export function getCurrentUser(): PowerPagesPortalUser | undefined {
  if (isDevelopment) return MOCK_USER
  return window.Microsoft?.Dynamic365?.Portal?.User
}

/**
 * Returns true if a user is currently logged in.
 */
export function isAuthenticated(): boolean {
  const user = getCurrentUser()
  return !!(user?.userName || user?.contactId || user?.email)
}

/**
 * Returns the Entra ID tenant ID from the portal configuration.
 */
export function getTenantId(): string | undefined {
  if (isDevelopment) return '00000000-0000-0000-0000-000000000000'
  return (window.Microsoft?.Dynamic365?.Portal as Record<string, unknown>)?.tenant as string | undefined
}

/**
 * Fetches the anti-forgery token required for the login form POST.
 * The token is embedded in an HTML response from /_layout/tokenhtml.
 */
export async function fetchAntiForgeryToken(): Promise<string> {
  const response = await fetch('/_layout/tokenhtml')
  const html = await response.text()
  const match = html.match(/value="([^"]+)"/)
  if (!match) {
    throw new Error('Failed to extract anti-forgery token from /_layout/tokenhtml')
  }
  return match[1]
}

/**
 * Initiates login by posting a form to the Power Pages external login endpoint.
 * The browser will redirect to Microsoft Entra ID for authentication.
 *
 * CRITICAL: Power Pages requires a form POST (not GET redirect) with:
 * - Anti-forgery token from /_layout/tokenhtml
 * - Provider URL: https://login.windows.net/{tenantId}/
 * - Return URL
 */
export async function login(returnUrl?: string): Promise<void> {
  if (isDevelopment) {
    console.warn('[Auth] Login is not available in local development. Using mock user.')
    window.location.reload()
    return
  }

  const token = await fetchAntiForgeryToken()
  const tenantId = getTenantId()

  const form = document.createElement('form')
  form.method = 'POST'
  form.action = '/Account/Login/ExternalLogin'

  const fields: Record<string, string> = {
    __RequestVerificationToken: token,
    provider: `https://login.windows.net/${tenantId}/`,
    returnUrl: returnUrl || window.location.pathname + window.location.search,
  }

  for (const [name, value] of Object.entries(fields)) {
    const input = document.createElement('input')
    input.type = 'hidden'
    input.name = name
    input.value = value
    form.appendChild(input)
  }

  document.body.appendChild(form)
  form.submit()
}

/**
 * Logs the user out by redirecting to the Power Pages logout endpoint.
 */
export function logout(returnUrl?: string): void {
  if (isDevelopment) {
    console.warn('[Auth] Logout is not available in local development.')
    window.location.reload()
    return
  }

  const target = returnUrl || '/'
  window.location.href = `/Account/Login/LogOff?returnUrl=${encodeURIComponent(target)}`
}

/**
 * Returns the user's display name (full name if available, otherwise userName).
 */
export function getUserDisplayName(): string {
  const user = getCurrentUser()
  if (!user) return ''
  const fullName = [user.firstName, user.lastName].filter(Boolean).join(' ')
  return fullName || user.email || user.userName || 'User'
}

/**
 * Returns the user's initials for avatar display.
 */
export function getUserInitials(): string {
  const user = getCurrentUser()
  if (!user) return ''
  if (user.firstName && user.lastName) {
    return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase()
  }
  return (user.userName?.[0] || user.email?.[0] || 'U').toUpperCase()
}
