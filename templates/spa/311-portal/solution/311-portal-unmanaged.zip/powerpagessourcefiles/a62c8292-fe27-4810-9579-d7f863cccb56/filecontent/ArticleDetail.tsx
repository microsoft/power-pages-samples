import { useParams, Link } from 'react-router-dom'
import { useMemo } from 'react'
import { FileText } from 'lucide-react'
import { useArticleBySlug } from '../shared/hooks/useArticles'
import { knowledgeArticles as localArticles } from '../data/articles'
import { serviceTypes } from '../data/categories'
import { useI18n } from '../i18n'
import Breadcrumbs from '../components/Breadcrumbs'
import EmptyState from '../components/EmptyState'
import { SkeletonDetail } from '../components/Skeleton'

export default function ArticleDetail() {
  const { slug } = useParams<{ slug: string }>()
  const { article, isLoading, error } = useArticleBySlug(slug)
  const { t, language } = useI18n()

  const dateLocale = language === 'fr' ? 'fr-CA' : 'en-US'

  // Find the primary related service slug for the "Create Service Request" CTA
  // Article relatedServiceTypeIds use the service ID (e.g. 'streetlight'),
  // but the route needs the service slug (e.g. 'streetlight-outage').
  const relatedServiceSlug = useMemo(() => {
    if (!slug) return null
    const local = localArticles.find(a => a.slug === slug)
    const serviceId = local?.relatedServiceTypeIds?.[0]
    if (!serviceId) return null
    const service = serviceTypes.find(s => s.id === serviceId)
    return service?.slug ?? null
  }, [slug])

  if (isLoading) {
    return <SkeletonDetail />
  }

  if (error) {
    return (
      <div className="page">
        <div className="container">
          <EmptyState
            icon={<FileText size={32} />}
            title={t('articleDetail.loadError')}
            description={error}
            action={<Link to="/knowledge" className="btn btn-primary">{t('articleDetail.browseKnowledgeBase')}</Link>}
          />
        </div>
      </div>
    )
  }

  if (!article) {
    return (
      <div className="page">
        <div className="container">
          <EmptyState
            icon={<FileText size={32} />}
            title={t('articleDetail.notFound')}
            description={t('articleDetail.notFoundDesc')}
            action={<Link to="/knowledge" className="btn btn-primary">{t('articleDetail.browseKnowledgeBase')}</Link>}
          />
        </div>
      </div>
    )
  }

  // Simple markdown-like rendering
  function renderContent(content: string) {
    return content.split('\n').map((line, i) => {
      if (line.startsWith('## ')) return <h2 key={i} style={{ fontSize: '1.375rem', marginTop: 32, marginBottom: 12 }}>{line.slice(3)}</h2>
      if (line.startsWith('### ')) return <h3 key={i} style={{ fontSize: '1.125rem', marginTop: 24, marginBottom: 8 }}>{line.slice(4)}</h3>
      if (line.startsWith('- ')) return <li key={i} style={{ marginLeft: 20, marginBottom: 4, lineHeight: 1.6 }}>{line.slice(2)}</li>
      if (line.match(/^\d+\./)) return <li key={i} style={{ marginLeft: 20, marginBottom: 4, lineHeight: 1.6 }}>{line.replace(/^\d+\.\s*/, '')}</li>
      if (line.trim() === '') return <br key={i} />
      // Bold text
      const parts = line.split(/\*\*(.*?)\*\*/)
      if (parts.length > 1) {
        return (
          <p key={i} style={{ lineHeight: 1.7, marginBottom: 4 }}>
            {parts.map((part, j) => j % 2 === 1 ? <strong key={j}>{part}</strong> : part)}
          </p>
        )
      }
      return <p key={i} style={{ lineHeight: 1.7, marginBottom: 4 }}>{line}</p>
    })
  }

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 800 }}>
        <Breadcrumbs items={[
          { label: t('common.home'), to: '/' },
          { label: t('common.knowledgeBase'), to: '/knowledge' },
          { label: article.title },
        ]} />

        <article>
          <header className="animate-in animate-in-1" style={{ marginBottom: 32 }}>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
              {article.tags.map(tag => (
                <span key={tag} className="badge badge-neutral">{tag}</span>
              ))}
            </div>
            <h1 style={{ fontSize: '2rem', lineHeight: 1.3, marginBottom: 8 }}>{article.title}</h1>
            <p style={{ fontSize: '1.0625rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>{article.summary}</p>
            <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-light)', fontFamily: 'var(--font-mono)', marginTop: 8 }}>
              {t('articleDetail.published')} {new Date(article.publishedAt).toLocaleDateString(dateLocale, { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>
          </header>

          <div className="card animate-in animate-in-2" style={{ padding: 40 }}>
            <div style={{ fontSize: '0.9375rem', color: 'var(--color-text)' }}>
              {renderContent(article.content)}
            </div>
          </div>

          <div className="animate-in animate-in-3" style={{ marginTop: 32, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <Link to={relatedServiceSlug ? `/request/new/${relatedServiceSlug}` : '/services'} className="btn btn-accent">
              {t('serviceDetail.createRequest')}
            </Link>
            <Link to="/knowledge" className="btn btn-secondary">
              {t('articleDetail.backToKnowledgeBase')}
            </Link>
          </div>
        </article>
      </div>
    </div>
  )
}
