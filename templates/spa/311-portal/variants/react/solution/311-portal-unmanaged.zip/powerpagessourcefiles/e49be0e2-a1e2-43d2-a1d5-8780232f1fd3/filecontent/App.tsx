import { Routes, Route, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import Layout from './components/Layout'
import AuthGate from './components/AuthGate'
import { useI18n } from './i18n'
import Home from './pages/Home'
import Services from './pages/Services'
import ServiceDetail from './pages/ServiceDetail'
import CreateRequest from './pages/CreateRequest'
import Track from './pages/Track'
import RequestMap from './pages/RequestMap'
import Knowledge from './pages/Knowledge'
import ArticleDetail from './pages/ArticleDetail'
import Contact from './pages/Contact'
import Admin from './pages/Admin'
import Login from './pages/Login'
import Registration from './pages/Registration'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import RedeemInvitation from './pages/RedeemInvitation'
import ExternalLoginConfirmation from './pages/ExternalLoginConfirmation'
import UserProfile from './pages/UserProfile'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => { window.scrollTo(0, 0) }, [pathname])
  return null
}

export default function App() {
  const { t } = useI18n()

  return (
    <Layout>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<Services />} />
        <Route path="/services/:slug" element={<ServiceDetail />} />
        <Route path="/request/new/:slug" element={
          <AuthGate message={t('auth.signInToSubmit')}>
            <CreateRequest />
          </AuthGate>
        } />
        <Route path="/track" element={
          <AuthGate message={t('auth.signInToTrack')}>
            <Track />
          </AuthGate>
        } />
        <Route path="/requests/map" element={<RequestMap />} />
        <Route path="/knowledge" element={<Knowledge />} />
        <Route path="/knowledge/:slug" element={<ArticleDetail />} />
        <Route path="/contact" element={<Contact />} />

        {/* Auth. These replace the server-rendered Power Pages pages; the
            Code-Site-Shell-Header web template rewrites the server URLs here. */}
        <Route path="/login" element={<Login />} />
        <Route path="/registration" element={<Registration />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/redeem-invitation" element={<RedeemInvitation />} />
        <Route path="/external-login-confirmation" element={<ExternalLoginConfirmation />} />

        {/* Not /profile — that path is reserved by the Power Pages server for its
            own legacy profile page. */}
        <Route path="/user-profile" element={<UserProfile />} />

        <Route path="/admin" element={<Admin />} />
      </Routes>
    </Layout>
  )
}
