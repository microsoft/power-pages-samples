import{r as o}from"./index-C7zo-jtK.js";const t="Supplier Invoice Portal";function u(e){o.useEffect(()=>(document.title=e?`${e} | ${t}`:t,()=>{document.title=t}),[e])}export{u};
