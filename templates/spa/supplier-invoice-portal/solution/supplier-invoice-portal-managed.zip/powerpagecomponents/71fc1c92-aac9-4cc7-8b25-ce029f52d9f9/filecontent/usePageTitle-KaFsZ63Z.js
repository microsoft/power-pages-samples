import{r as o}from"./index-BJT4QhbK.js";const t="Supplier Invoice Portal";function u(e){o.useEffect(()=>(document.title=e?`${e} | ${t}`:t,()=>{document.title=t}),[e])}export{u};
