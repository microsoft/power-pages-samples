# AGENTS.md

This file provides guidance to AI coding agents when working with code in this repository.

## What this is

A **Supplier Invoice Portal** - a React 19 + TypeScript + Vite SPA deployed as a Power Pages **BYOC (Bring Your Own Code) code site**, backed by Dataverse. Suppliers submit invoices against purchase orders and track status; reviewers approve/reject from a queue. There is no custom backend: Power Pages provides auth, authorization (web roles + table permissions), the Dataverse Web API, file storage, and hosting.

Styling is plain CSS via `src/styles/theme.css` and CSS variables (`var(--color-primary)`, `var(--font-heading)`), not Tailwind despite the PRD wording. Icons are `lucide-react`. Routing is `react-router-dom` v7.

## Commands

```bash
npm run dev          # Vite dev server - runs against MOCK data (see dev/prod switch below)
npm run build        # tsc -b -> vite build -> scripts/postbuild.js (REQUIRED full chain)
npm run preview      # preview the production build locally

# Deploy (requires pac CLI auth to the environment)
pac auth create --url https://org1cc6ae5d.crm.dynamics.com
pac pages upload-code-site --path .powerpages-site

# Dataverse sample-data migration between environments
npm run dataverse:export   # export contacts/suppliers/POs/invoices/comments/attachments + file binaries
npm run dataverse:import -- --target https://TARGET.crm.dynamics.com --in dataverse-export\supplier-portal [--dry-run]
```

There is **no test runner and no separate lint step** - type-checking via `tsc` (run as part of `npm run build`, or `npx tsc --noEmit`) is the only static gate. `tsconfig.json` has `strict`, `noUnusedLocals`, and `noUnusedParameters` on, so unused code fails the build.

**Always run the full `npm run build`, never `vite build` alone.** `scripts/postbuild.js` scans `dist/assets/` and rewrites `bundleFilePatterns` in `powerpages.config.json`; this is what tells `pac pages upload-code-site` which hashed bundles to upload and clean up. Skipping it leaves stale bundles on the deployed site.

## Architecture: the layered data flow

Requests flow **page -> provider hook -> service -> powerPagesApi -> Dataverse**. Understand these layers before changing data code:

1. **Pages** (`src/pages/`) - route components, lazy-loaded and wrapped in `<RequireAuth>` in `src/App.tsx`. Pages never call services or `fetch` directly; they consume provider hooks.

2. **Provider layer** (`src/data/invoiceProvider.ts`, `purchaseOrderProvider.ts`) - **this is the single most important file pattern.** Providers expose React hooks (`useInvoiceList`, `useInvoiceDetail`, `useCreateInvoiceAction`, etc.) and contain the **dev/prod switch**:

   ```ts
   const isDevelopment = window.location.hostname === 'localhost' || '127.0.0.1'
   ```

   When `isDevelopment`, hooks return data from `src/data/mockData.ts`. Otherwise they dynamically `import()` the service layer and hit the live Web API. **Every provider hook has both branches - when you add or change a data operation, you must update both the mock branch and the live branch**, plus the mapper that converts API types -> UI types (`apiInvoiceToItem`, etc.).

3. **Service layer** (`src/services/*Service.ts`) - typed Dataverse OData CRUD for one table each (`invoiceService`, `purchaseOrderService`, `invoiceCommentService`, `invoiceAttachmentService`). Services speak raw Dataverse logical names (`spnvc_*`) and map entities to clean domain types defined in `src/types/`.

4. **`src/services/powerPagesApi.ts`** - the centralized Web API client every service goes through. Owns: anti-forgery token fetch/cache (`/_layout/tokenhtml`), retry with backoff (429/5xx) + 403 token refresh, OData URL/filter builders, `@odata.bind` lookup helper, formatted-value extraction, and the **file-column helpers**. Read this file before touching any data-fetch code.

### Non-OData services (do NOT route through powerPagesApi)

Two services deliberately use raw `fetch` because their endpoints are not OData and must not receive the default `Prefer: odata.include-annotations` header. They reuse only `getCsrfToken` from `powerPagesApi`:

- **`aiSummaryService.ts`** - Power Pages generative-AI Data Summarization + Search Summary APIs (`/_api/summarization/...`, `/_api/search/v1.0/summary`). Requires `OData-MaxVersion/Version: 4.0` and `X-Requested-With` headers.
- **`cloudFlowService.ts`** - cloud-flow triggers (`/_api/cloudflow/v1.0/trigger/<flowId>`). Each flow is registered via a `.cloudflowconsumer.yml` under `.powerpages-site/cloud-flow-consumer/` and gated to a web role. Payload is `{ eventData: JSON.stringify(payload) }`.

### Auth & authorization

- **`src/services/authService.ts`** - `getCurrentUser()` returns mock users (`MOCK_SUPPLIER` / `MOCK_REVIEWER`, toggled via the `DevRoleSwitcher` / localStorage `mock-role`) on localhost, and `window.Microsoft.Dynamic365.Portal.User` on the deployed site. Login/logout POST to Power Pages endpoints; **auth only works on the deployed site**, not locally.
- **`src/utils/authorization.ts`** - role checks (`isReviewer()`, `isSupplier()`, `hasRole()`). **Client-side authorization is UX-only.** Real access control is enforced server-side by table permissions - see the top-of-file comment. Never rely on these checks for security.

## Dataverse data model

Custom tables use the `spnvc_` publisher prefix (see `.datamodel-manifest.json`):

| Table | Notes |
|---|---|
| `spnvc_invoice` | `spnvc_name` is the invoice number (primary). Status is a Picklist - values defined in `INVOICE_STATUS` (`src/types/invoice.ts`): Draft=1, Submitted=2, Under Review=3, Needs Revision=4, Approved=5, Rejected=6, Paid=7. |
| `spnvc_purchaseorder` | |
| `spnvc_invoicecomment` | `spnvc_contactid` binds the **invoice owner's** contact (not the author) so both supplier and reviewer comments are visible to the supplier - required for contact-scope permissions. |
| `spnvc_invoiceattachment` | `spnvc_file` is a Dataverse **File column**. |
| `contact`, `spnvc_supplier` | Reused standard/existing tables. |

### Dataverse Web API gotchas (already handled in powerPagesApi - preserve these)

- **Lookups** use `@odata.bind` with **case-sensitive Navigation Property names** (`spnvc_ContactId`, `spnvc_SupplierId` - capitalized), not the lowercase logical column names. Set via `bindLookup()`.
- **Pagination** uses `@odata.nextLink` cursors - Dataverse does **not** support `$skip`. Use `fetchAllPages()` for full sweeps.
- **File columns** (upload/download/delete) MUST send `Content-Type: application/octet-stream` - the OData pipeline routes binary on this header. Upload is `PATCH /_api/{table}({id})/{column}` (no `/$value`); download is `GET .../{column}/$value`. Sending the real MIME type causes "Stream was not readable" (CDS 0x80048d19). See file-column helper comments.
- **Aggregations** - Power Pages Web API rejects multiple aggregate expressions in one `$apply`; split into separate requests (see `getInvoiceAmountStats`).
- Every **mutating** request needs the `__RequestVerificationToken` header (handled by `buildPowerPagesHeaders`).

## Power Pages site config (`.powerpages-site/`)

This directory is the deployable site definition (uploaded by `pac pages upload-code-site`):

- `web-files/` - the compiled React bundles + static assets (mirror of `dist`).
- `table-permissions/` - row-level security. Invoices/comments/attachments use **contact-scope** (suppliers see only their own) plus separate **Reviewer-Access** permissions. When adding a table or a write path, you must add matching table permission YAML or the live Web API call returns a permission-denied error (codes in `WebApiErrorCode`).
- `web-roles/` - Supplier, Reviewer, Administrators, Authenticated/Anonymous Users.
- `site-settings/`, `content-snippets/`, `sitemarkers/`, `cloud-flow-consumer/`.

`docs/` contains generated plan/audit HTML (data model, permissions, cloud flow, ALM) and `dataverse-data-migration.md`.
