import { type ReactNode, useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { Menu } from 'lucide-react'
import Sidebar from './Sidebar'

const publicRoutes = ['/']

export default function Layout({ children }: { children: ReactNode }) {
  const { pathname } = useLocation()
  const isPublic = publicRoutes.includes(pathname)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  // Close sidebar on route change
  useEffect(() => {
    setSidebarOpen(false)
  }, [pathname])

  if (isPublic) {
    return <>{children}</>
  }

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      {/* Skip to content — accessibility */}
      <a href="#main-content" className="skip-to-content">
        Skip to main content
      </a>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(42, 31, 22, 0.5)',
            zIndex: 40,
          }}
          className="sidebar-overlay"
        />
      )}

      {/* Sidebar */}
      <div
        className={`sidebar-container ${sidebarOpen ? 'sidebar-open' : ''}`}
      >
        <Sidebar onClose={() => setSidebarOpen(false)} />
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        {/* Mobile header - only hamburger menu */}
        <div className="mobile-topbar">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            aria-label="Open navigation menu"
            className="mobile-menu-btn btn-ghost"
            style={{ color: 'var(--color-text)' }}
          >
            <Menu size={20} aria-hidden="true" />
          </button>
        </div>

        <main
          id="main-content"
          className="main-content"
          style={{
            flex: 1,
            overflow: 'auto',
          }}
        >
          {children}
        </main>
      </div>
    </div>
  )
}
