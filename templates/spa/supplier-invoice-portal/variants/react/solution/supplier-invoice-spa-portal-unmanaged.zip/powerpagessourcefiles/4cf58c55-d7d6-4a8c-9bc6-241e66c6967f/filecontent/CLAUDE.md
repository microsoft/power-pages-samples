# CLAUDE.md

Read `AGENTS.md` before working in this repository.
Treat it as the shared source of repository guidance, including architecture, commands, data-flow rules, and deployment notes.