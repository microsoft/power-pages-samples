# Doc update draft: Create code sites bundle cleanup and code splitting

> **Purpose of this file:** a reviewable draft of additions/edits proposed for
> [Create and deploy a single-page application in Power Pages](https://learn.microsoft.com/en-us/power-pages/configure/create-code-sites).
> It contains **(A)** a rewrite of the existing `powerpages.config.json` subsection and
> **(B)** a brand-new section on code splitting and bundle cleanup. Text is written to
> drop directly into `power-pages-docs/configure/create-code-sites.md`.
>
> Sections (A) and (B) below are the publishable content. The "Authoring notes" section
> at the end is **not** for publication. It records the Microsoft Learn style review.

---

## (A) REWRITE: replaces the existing "Defining upload parameters with `powerpages.config.json`" subsection

#### Defining upload parameters with `powerpages.config.json`

Customize the behavior of the `upload-code-site` command by including a `powerpages.config.json` file in your site's root folder. When this file is present, run `upload-code-site` with only the `--rootPath` parameter. The command reads the remaining values from the configuration file. If you supply both command-line arguments and configuration values, the command-line arguments take precedence.

##### Configuration fields

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `siteName` | string | Yes | Display name for the Power Pages site. |
| `compiledPath` | string | Yes | Path to the compiled output directory (for example, the Vite `dist` or React `build` folder), relative to `powerpages.config.json`. |
| `defaultLandingPage` | string | Yes | The HTML page served when the site root is opened, relative to `compiledPath` (typically `index.html`). |
| `bundleFilePatterns` | string[] | No | A list of wildcard patterns identifying files in the site's `web-files` that the CLI removes before uploading the new build. Use this field to clean up stale, content-hashed bundles so old assets don't accumulate on the site. See [Code splitting and bundle cleanup](#code-splitting-and-bundle-cleanup). |
| `includeSource` | boolean | No | When `true`, the command uploads your source code in addition to the compiled assets. Defaults to `false`. |
| `sourceExcludePatterns` | string[] | No | Wildcard patterns for source files to exclude from upload. Applies only when `includeSource` is `true` (for example, to skip `node_modules` or local environment files). |

For the authoritative and always-current field reference, including any fields added in later releases, see the [`powerpages.config.json` schema](https://www.schemastore.org/powerpages.config.json). Add the matching `$schema` property to your configuration file to enable validation and autocomplete in editors that support JSON Schema.

##### Sample `powerpages.config.json`

```json
{
  "$schema": "https://www.schemastore.org/powerpages.config.json",
  "siteName": "Contoso Bank",
  "compiledPath": "dist",
  "defaultLandingPage": "index.html",
  "bundleFilePatterns": [
    "index-*.js",
    "index-*.css"
  ]
}
```

---

## (B) NEW SECTION: insert after "Project structure and configuration"

## Code splitting and bundle cleanup

As a single-page application grows, a single JavaScript bundle becomes large and slow to load. Modern build tools solve this with **code splitting**, which breaks the app into smaller **chunks** that the browser downloads on demand (for example, only when the user navigates to a specific route). Each chunk is emitted with a **content hash** in its file name, such as `Dashboard-BSbmIXoe.js`, so browsers can cache it for long periods and re-download it only when its contents change.

Code splitting introduces a deployment consideration unique to Power Pages SPA sites: because every build produces new hashed file names, repeated `upload-code-site` runs would leave the old hashed files behind on the site. Over many deployments, these orphaned chunks accumulate in the site's `web-files`. The `bundleFilePatterns` field in `powerpages.config.json` exists to clean them up.

### Enable code splitting

Code splitting is handled by your front-end build tool, not by Power Pages, so the approach depends on the framework and bundler you use. The most common technique is to load parts of the app with dynamic imports, often applied at the route or view level so that each section downloads only when a user navigates to it (lazy loading).

The frameworks supported for SPA sites each provide an idiomatic way to split code:

- **React**: lazy-load route components and render them inside a suspense boundary.
- **Angular**: configure lazy-loaded routes in the router.
- **Vue**: register routes with dynamically imported components.

Bundlers such as Vite, Rollup, webpack, and esbuild can also group modules into named chunks explicitly. For the exact configuration, see the documentation for your framework and bundler.

Whichever approach you choose, the outcome is the same, and it's the part that matters for deployment: the build emits multiple output files, each with a content hash in its name. Because those hashes change whenever a file's contents change, every build produces a different set of file names. The next sections explain how to keep your site clean as those names change.

### How `upload-code-site` cleans up stale bundles

Before uploading your compiled assets, `upload-code-site` deletes every file in the site's `web-files` that matches a wildcard pattern in `bundleFilePatterns`, then uploads the current build. This delete-then-upload behavior keeps the deployed file set identical to your latest compiled output instead of layering each build on top of the previous one.

For the cleanup to work, the wildcard patterns in `bundleFilePatterns` must match the file names your build emits. There are two ways to keep them accurate, depending on how your build tool names files.

### Option 1: List wildcard patterns directly

Many build tools keep a stable name prefix and change only the content hash, such as `index-[hash].js`. When your output file names follow a predictable pattern like this, list a wildcard pattern for each one in `bundleFilePatterns`. No extra tooling is needed:

```json
{
  "$schema": "https://www.schemastore.org/powerpages.config.json",
  "siteName": "Contoso Bank",
  "compiledPath": "dist",
  "defaultLandingPage": "index.html",
  "bundleFilePatterns": [
    "index-*.js",
    "index-*.css"
  ]
}
```

A wildcard pattern such as `index-*.js` matches that file on every build, regardless of the hash. Add one entry per output file, and add a new pattern whenever your build starts producing a new output file.

### Option 2: Generate wildcard patterns with a post-build script

Use this approach when your output file names don't follow a predictable pattern, or when your app produces many files whose names change as you add and remove routes, which makes a hand-maintained list error-prone. A short script that runs after the build scans the compiled output and rewrites `bundleFilePatterns` with a wildcard pattern for each emitted file. For example, when a build tool names files as `[name]-[hash].[ext]`, the script reduces `Dashboard-BSbmIXoe.js` to the pattern `Dashboard-*.js`.

`scripts/postbuild.js`:

```js
#!/usr/bin/env node

/**
 * Post-build step: scan the compiled assets folder and update
 * bundleFilePatterns in powerpages.config.json so that
 * `pac pages upload-code-site` cleans up old hashed bundles on each
 * deploy instead of accumulating stale files.
 */

import { readdirSync, readFileSync, writeFileSync } from 'fs'
import { join } from 'path'

const ROOT = join(import.meta.dirname, '..')
const DIST_ASSETS = join(ROOT, 'dist', 'assets')
const CONFIG_PATH = join(ROOT, 'powerpages.config.json')

// Vite/Rollup output format: [name]-[hash].[ext]
// Capture "name" and "ext" to produce a "name-*.ext" pattern.
const HASH_PATTERN = /^(.+)-[A-Za-z0-9_-]{6,12}\.(js|css)$/

const files = readdirSync(DIST_ASSETS)
const patterns = new Set()

for (const file of files) {
  const match = file.match(HASH_PATTERN)
  if (match) {
    const [, baseName, ext] = match
    patterns.add(`${baseName}-*.${ext}`)
  }
}

const config = JSON.parse(readFileSync(CONFIG_PATH, 'utf-8'))
config.bundleFilePatterns = [...patterns].sort()
writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2) + '\n', 'utf-8')

console.log(`Updated bundleFilePatterns with ${patterns.size} pattern(s).`)
```

Wire the script into your build so it always runs after the bundler:

```json
{
  "scripts": {
    "build": "tsc -b && vite build && node scripts/postbuild.js"
  }
}
```

> [!NOTE]
> If your tooling honors npm lifecycle scripts, you can instead name the script `postbuild` so it runs automatically after `build`:
> `"postbuild": "node scripts/postbuild.js"`.

Now a deployment is two commands, and the site never accumulates orphaned chunks:

```powershell
npm run build
pac pages upload-code-site --rootPath .
```

After the build, `powerpages.config.json` reflects the exact current bundles, for example:

```json
{
  "$schema": "https://www.schemastore.org/powerpages.config.json",
  "siteName": "Contoso Bank",
  "compiledPath": "dist",
  "defaultLandingPage": "index.html",
  "bundleFilePatterns": [
    "Dashboard-*.js",
    "InvoiceDetail-*.js",
    "InvoiceList-*.js",
    "index-*.css",
    "index-*.js"
  ]
}
```

---

## Authoring notes (NOT for publication)

Microsoft Learn style review of sections (A) and (B):

| Guideline | Status |
| --- | --- |
| Second person, active voice, present tense | Pass |
| Sentence-case headings | Pass |
| Banned/informal words (*just*, *simply*, *easy*, *leverage*, *please*) | Removed; none remain |
| "configuration" spelled out (no informal *config* as a noun in prose) | Pass |
| Latin abbreviations (*e.g.*, *i.e.*, *etc.*) replaced with *for example* / *that is* | Pass |
| "file name" spelled as two words | Pass |
| Bold reserved for new-term introductions and list lead-in labels, not for emphasis | Pass |
| Plain-language "wildcard pattern" used instead of the jargon term *glob* | Pass |
| Em-dash not used; replaced with periods, colons, or commas | Pass |
| Alerts use `> [!NOTE]` / `> [!TIP]` syntax with complete sentences | Pass |
| Fenced code blocks declare a language | Pass |
| Descriptive link text (no "click here"); external links use full URLs | Pass |
| Numbers zero–nine spelled out in prose | Pass |
| Serial (Oxford) comma | Pass |
| No directional language ("above"/"below") for cross-references | Pass; uses an anchor link |

**Before merging the PR into `power-pages-docs/configure/create-code-sites.md`:**

- Update the frontmatter `ms.date` to the publication date.
- Confirm the cross-reference anchor `#code-splitting-and-bundle-cleanup` matches the rendered heading slug.
- Verify the cleanup scope claim (files removed from `web-files` matching `bundleFilePatterns`) against current PAC CLI behavior before publishing.
- Confirm the canonical schema URL to link. This draft uses the SchemaStore URL (`https://www.schemastore.org/powerpages.config.json`); link to a Microsoft-hosted schema instead if one is published.
- Decide whether the canonical sample uses the configuration-driven `--rootPath .` form (shown here) or a separate compiled-site folder, and keep it consistent with the rest of the article.
