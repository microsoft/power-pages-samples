/**
 * Power Pages Server Logic - Google reCAPTCHA validation + create Callback Request
 *
 * The client sends the reCAPTCHA token plus the form fields, e.g.:
 *   {
 *     "token":      "<g-recaptcha-response>",
 *     "fullName":   "Jane Doe",
 *     "phone":      "+1 555 0100",
 *     "email":      "jane@contoso.com",
 *     "bestTime":   100000000            // choice value (optional)
 *   }
 *
 * The POST method verifies the token with Google, and only if verification
 * succeeds does it create a Callback Request record in Dataverse.
 */

const RECAPTCHA_SECRET = Server.SiteSetting.Get("RecaptchaSecretKey");
const VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify";
const ENTITY_SET_NAME = "sample_callbackrequests"; // plural logical name of the table

async function post() {
    try {
        Server.Logger.Log("POST called - validating reCAPTCHA token");

        if (!RECAPTCHA_SECRET) {
            Server.Logger.Error("Missing site setting: RecaptchaSecretKey");
            return JSON.stringify({ status: "error", method: "POST", success: false, message: "Server is not configured. Please try again later." });
        }

        const rawBody = Server.Context.Body;

        let body = {};
        if (rawBody && rawBody !== "undefined") {
            try {
                body = JSON.parse(rawBody);
            } catch (parseErr) {
                Server.Logger.Error("Invalid JSON body: " + parseErr.message);
                return JSON.stringify({ status: "error", method: "POST", success: false, message: "Request body is not valid JSON" });
            }
        }

        const token = body.token;

        if (!token) {
            const errorMsg = "Missing required field: token";
            Server.Logger.Error(errorMsg);
            return JSON.stringify({ status: "error", method: "POST", success: false, message: errorMsg });
        }

        // ----- 1. Verify the reCAPTCHA token with Google -----
        const verifyUrl = `${VERIFY_URL}?secret=${encodeURIComponent(RECAPTCHA_SECRET)}&response=${encodeURIComponent(token)}`;

        const responseRaw = await Server.Connector.HttpClient.PostAsync(
            verifyUrl,
            "",
            {},
            "application/x-www-form-urlencoded");

        const response = typeof responseRaw === "string" ? JSON.parse(responseRaw) : responseRaw;

        if (!response || !response.Body) {
            Server.Logger.Error("Empty response from siteverify");
            return JSON.stringify({ status: "error", method: "POST", success: false, message: "No response from reCAPTCHA verification service" });
        }

        const result = JSON.parse(response.Body);

        if (!result.success) {
            Server.Logger.Error("reCAPTCHA validation failed: " + JSON.stringify(result["error-codes"] || []));
            return JSON.stringify({ status: "error", method: "POST", success: false, message: "CAPTCHA verification failed. Please try again." });
        }

        Server.Logger.Log("reCAPTCHA validation succeeded - creating Callback Request");

        // ----- 2. Build the Dataverse record from the submitted fields -----
        if (!body.fullName || !body.phone) {
            return JSON.stringify({ status: "error", method: "POST", success: false, message: "Full name and phone number are required." });
        }

        const record = {
            sample_name: body.fullName,
            sample_phonenumber: body.phone
        };
        if (body.email) {
            record.sample_email = body.email;
        }
        if (body.bestTime !== undefined && body.bestTime !== null && body.bestTime !== "") {
            const bestTime = Number(body.bestTime);
            if (!Number.isNaN(bestTime)) {
                record.sample_besttimetocall = bestTime;
            }
        }

        // ----- 3. Create the record in Dataverse -----
        const createResultRaw = await Server.Connector.Dataverse.CreateRecord(ENTITY_SET_NAME, JSON.stringify(record));
        const createResult = typeof createResultRaw === "string" ? JSON.parse(createResultRaw) : createResultRaw;

        // CreateRecord resolves even when Dataverse rejects the payload, so
        // inspect the status before reporting success to the client. Log the
        // full server error, but return only a generic message to the browser.
        if (createResult && createResult.IsSuccessStatusCode === false) {
            Server.Logger.Error("Dataverse CreateRecord failed: " + JSON.stringify(createResult.ReasonPhrase || createResult));
            return JSON.stringify({
                status: "error",
                method: "POST",
                success: false,
                message: "Your request could not be saved. Please try again later."
            });
        }

        Server.Logger.Log("Callback Request created");

        return JSON.stringify({
            status: "success",
            method: "POST",
            success: true,
            message: "Thanks! Your callback request has been received - we'll call you shortly."
        });

    } catch (err) {
        Server.Logger.Error("POST failed: " + err.message);
        return JSON.stringify({ status: "error", method: "POST", success: false, message: "An unexpected error occurred. Please try again later." });
    }
}
